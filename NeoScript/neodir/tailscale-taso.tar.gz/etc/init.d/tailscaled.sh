#!/bin/sh
#tu mozesz dodac w;asne script

@reboot sleep 90 ; modprobe tun; /usr/bin/tailscaled -port 4434 -tun userspace-networking

if [ -e /home/root/.cache/tailscale-update ] ; then
        rm -r  /home/root/.cache/tailscale-update
        mkdir /tmp/tailscale-update
        ln -sf "/tmp/tailscale-update" "/home/root/.cache/tailscale-update";
        
fi

exit 0
