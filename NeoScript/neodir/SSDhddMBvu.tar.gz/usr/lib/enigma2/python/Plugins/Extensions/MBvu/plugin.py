# -*- coding: utf-8 -*-
## Multiboot Image Selector VU+ALL
## Script by gutosie
##
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from os import listdir
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.Screen import Screen
import os
import sys
from os import system
from Tools.Directories import fileExists, SCOPE_PLUGINS
from Screens.MessageBox import MessageBox
from Plugins.Extensions.MBvu.getinfo import dirIscripts, dirscripts, namber, getMovNextIMG, getHddOrUsb, getMountDevices,  getS0, getS1, getS2, getS3, getS4, getS5, getS6, getS7, getS8, getS9, getS10, getS11, getS12, getS13, getS14, getS15, getS16, getS17, getS18, getS19, getS20, getImageTeam0, getImageTeam1, getImageTeam2, getImageTeam3, getImageTeam4, getImageTeam5, getImageTeam6, getImageTeam7, getImageTeam8, getImageTeam9, getImageTeam10, getImageTeam11, getImageTeam12, getImageTeam13, getImageTeam14, getImageTeam15, getImageTeam16, getImageTeam17, getImageTeam18, getImageTeam19, getImageTeam20

PLUGINVERSION=open('/usr/lib/enigma2/python/Plugins/Extensions/MBvu/mbvuver').read().strip().upper()
autoupdateplug = 'https://raw.githubusercontent.com/gutosie/neoscript/main/NeoScript/neodir/imbvuver'

class ScriptNeo(Screen):
        skin = """
	<screen position="center,center" size="930,555" title="Select SLOT Image       Plug ver.: %s">   
            <widget name="list" itemHeight="44" font="Regular;35" position="center,center" zPosition="1" size="870,500" scrollbarMode="showOnDemand" transparent="1">
            <convert type="StringList" font="Regular;70" />
          </widget>
	</screen>""" % (_(''+PLUGINVERSION+''))
	
        if fileExists('/tmp/imbvuver'):
                os.system('rm -r /tmp/imbvuver')
        try:
                os.system('rm -r /tmp/imbvuver; cd /tmp; wget -q --no-check-certificate '+autoupdateplug+' ')
        except:o
                s.system('rm -r /tmp/imbvuver; cd /tmp; curl -O --ftp-ssl -k '+autoupdateplug+' ')
		
        if fileExists(''+getHddOrUsb()+'/linuxrootfs9/zImage'):
            getMovNextIMG()
        
        if not fileExists(''+getHddOrUsb()+'/linuxrootfs'+namber+'/'):
            getMountDevices()
            
        if fileExists(''+dirIscripts+'') and fileExists(''+dirscripts+'') :
                os.system('rm -r '+dirscripts+'/*.sh; sleep 2; mv '+dirIscripts+'/* '+dirscripts+'/; sleep 2  ')
        elif fileExists(''+dirIscripts+'') and not fileExists(''+dirscripts+''):
                os.system('mv -f '+dirIscripts+' '+dirscripts+'; sleep 2  ')
                
        os.system('mv -f ' + dirscripts + '/0_Slot0*.sh ' + dirscripts + '/0_Slot0-Recovery%s.sh' % getS0() )
        os.system('mv -f ' + dirscripts + '/1_Slot1*.sh ' + dirscripts + '/1_Slot1-' + getImageTeam1() + '%s.sh' % getS1() ) 
        os.system('mv -f ' + dirscripts + '/2_Slot2*.sh ' + dirscripts + '/2_Slot2-' + getImageTeam2() + '%s.sh' % getS2() )
        os.system('mv -f ' + dirscripts + '/3_Slot3*.sh ' + dirscripts + '/3_Slot3-' + getImageTeam3() + '%s.sh' % getS3() ) 
        if fileExists('/boot/STARTUP_'+namber+'') :
            os.system('mv -f ' + dirscripts + '/4_Slot4*.sh ' + dirscripts + '/4_Slot4-' + getImageTeam4() + '%s.sh' % getS4() )  
            os.system('mv -f ' + dirscripts + '/5_Slot5*.sh ' + dirscripts + '/5_Slot5-' + getImageTeam5() + '%s.sh' % getS5() )
            os.system('mv -f ' + dirscripts + '/6_Slot6*.sh ' + dirscripts + '/6_Slot6-' + getImageTeam6() + '%s.sh' % getS6() )
            os.system('mv -f ' + dirscripts + '/7_Slot7*.sh ' + dirscripts + '/7_Slot7-' + getImageTeam7() + '%s.sh' % getS7() )
            os.system('mv -f ' + dirscripts + '/8_Slot8*.sh ' + dirscripts + '/8_Slot8-' + getImageTeam8() + '%s.sh' % getS8() )
            os.system('mv -f ' + dirscripts + '/9_Slot9*.sh ' + dirscripts + '/9_Slot9-' + getImageTeam9() + '%s.sh' % getS9() )
            os.system('mv -f ' + dirscripts + '/Slot10*.sh ' + dirscripts + '/Slot10-' + getImageTeam10() + '%s.sh' % getS10() )
            os.system('mv -f ' + dirscripts + '/Slot11*.sh ' + dirscripts + '/Slot11-' + getImageTeam11() + '%s.sh' % getS11() )
            os.system('mv -f ' + dirscripts + '/Slot12*.sh ' + dirscripts + '/Slot12-' + getImageTeam12() + '%s.sh' % getS12() )
            os.system('mv -f ' + dirscripts + '/Slot13*.sh ' + dirscripts + '/Slot13-' + getImageTeam13() + '%s.sh' % getS13() )
            os.system('mv -f ' + dirscripts + '/Slot14*.sh ' + dirscripts + '/Slot14-' + getImageTeam14() + '%s.sh' % getS14() )
            os.system('mv -f ' + dirscripts + '/Slot15*.sh ' + dirscripts + '/Slot15-' + getImageTeam15() + '%s.sh' % getS15() )
            os.system('mv -f ' + dirscripts + '/Slot16*.sh ' + dirscripts + '/Slot16-' + getImageTeam16() + '%s.sh' % getS16() )
            os.system('mv -f ' + dirscripts + '/Slot17*.sh ' + dirscripts + '/Slot17-' + getImageTeam17() + '%s.sh' % getS17() )
            os.system('mv -f ' + dirscripts + '/Slot18*.sh ' + dirscripts + '/Slot18-' + getImageTeam18() + '%s.sh' % getS18() )
            os.system('mv -f ' + dirscripts + '/Slot19*.sh ' + dirscripts + '/Slot19-' + getImageTeam19() + '%s.sh' % getS19() )
            os.system('mv -f ' + dirscripts + '/Slot20*.sh ' + dirscripts + '/Slot20-' + getImageTeam20() + '%s.sh' % getS20() )  

        if fileExists(''+dirIscripts+''):
                os.system('sleep 2; rm -r '+dirIscripts+' ')
        if not fileExists('/STARTUP') and fileExists(''+dirscripts+'/_Move_Plugin.sh'):
                        os.system('rm -f '+dirscripts+'/_Move_Plugin.sh')
        if not fileExists('/STARTUP') and fileExists(''+dirscripts+'/_20') :
                        os.system('sh '+dirscripts+'/_Add_Next_Slots.sh')
        elif fileExists('/boot/STARTUP_20') and not fileExists(''+dirscripts+'/_20'):
                        os.system('rm -f '+dirscripts+'/_Add_Next_Slots.sh')
                
        os.system('chmod 755 '+dirscripts+'/*.sh')
                         
        def __init__(self, session, args=None):
                Screen.__init__(self, session)
                self.session = session
                self["list"] = MenuList([])
                self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.run, "cancel": self.close}, -1)
                self.onLayoutFinish.append(self.loadScriptList)
                
        def loadScriptList(self):              
                try:
                        list = listdir("/usr/lib/enigma2/python/Plugins/Extensions/MBvu/script/")
                        list.sort()
                        list = [x[:-3] for x in list if x.endswith('.sh')]
                except:
                        list = []
                
                self["list"].setList(list)

        def run(self):
                try:
                        script = self["list"].getCurrent()
                except:
                        script = None
                
                if script is not None:
                        title = script
                        script = "/usr/lib/enigma2/python/Plugins/Extensions/MBvu/script/%s.sh" % script
                
                self.session.open(Console, title, cmdlist=[script])
			
def checkimage():
    mycheck = False
    if fileExists('/proc/stb/info/vumodel') and not fileExists('/proc/stb/info/boxtype'):
        mycheck = True
    else:
        mycheck = False
    return mycheck
    
def main(session, **kwargs):
    if fileExists('/boot/STARTUP') and checkimage():
            session.open(ScriptNeo)
    else:
            session.open(MessageBox, _('Sorry: Wrong image in flash found. You have to install in flash VuPLUS Image or back to RECOVERY Slot0.'), MessageBox.TYPE_INFO, 8)

def startList(menuid):
    if menuid != 'mainmenu':
        return []
    else:
        return [(_('MBvu Selector'),         
          main,
          'tvlist',
          None)]

from Plugins.Plugin import PluginDescriptor

def Plugins(**kwargs):
    list = [PluginDescriptor(name='MBvu Selector', description='Boot Image', where=PluginDescriptor.WHERE_MENU, fnc=startList), PluginDescriptor(name='MBvu Selector', description=_('Boot Image'), icon='mbvu.png', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main)]
    list.append(PluginDescriptor(name=_('MBvu Selector'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main))
    return list
