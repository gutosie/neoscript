# -*- coding: utf-8 -*-
## Multiboot Image Selector VU+
## Script by gutosie
import sys
import os
from Tools.Directories import fileExists, SCOPE_PLUGINS

dirscripts='/usr/lib/enigma2/python/Plugins/Extensions/MBvu/script'
dirIscripts='/usr/lib/enigma2/python/Plugins/Extensions/MBvu/iscript'
namber='4' or '5' or '6' or '7' or '8' or '9' or '10' or '11' or '12' or '13' or '14' or '15' or '16' or '17' or '18' or '19' or '20' #itd.. add
namberout = '10' or '11' or '12' or '13' or '14' or '15' or '16' or '17' or '18' or '19' or '20' 

def getUnknownImage():
                    if fileExists('/boot/linuxrootfs1/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs2/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs3/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs3/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs4/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs5/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs6/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs7/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs8/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs9/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs10/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs11/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs12/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs13/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs14/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs15/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs16/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs17/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs18/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs119/etc/issue'):
                        imageteam = 'Unknown-image'
                    if fileExists('/boot/linuxrootfs20/etc/issue'):
                        imageteam = 'Unknown-image'  
                    else:
                        imageteam ='empty_Slot'
                    return imageteam                          

#Image Recovery Slot0
def getImageTeam0():
        imageteam = '_RECOVERY_Slot0'
        if fileExists('/usr/lib/enigma2/python/boxbranding.so') and fileExists('/STARTUP'):
            from boxbranding import getImageDistro
            imagedistro = getImageDistro()
            return imagedistro
        elif fileExists("/boot/etc/issue") and fileExists('/boot/STARTUP'):
            for line in open("/boot/etc/issue"):
                if "openbh" in line:
                    imageteam = 'OpenBH'          
        return imageteam
        
def getS0():
    try:
        slot0 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs0') != -1:
                slot0 = '____'+GetTranslator()+''
        return slot0
    except:
        pass

#Image Slot1
def getImageTeam1():
        imageteam = getUnknownImage()
        if fileExists('/boot/linuxrootfs1/etc/issue'):
            for line in open("/boot/linuxrootfs1/etc/issue"):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists('/boot/linuxrootfs1/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists('/boot/linuxrootfs1/etc/bhversion'):
                    for line in open('/boot/linuxrootfs1/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
                                              
        return imageteam
        
def getS1():
    try:
        slot1 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs1') != -1 and not lines.find(''+namberout+'') :
                slot1 = '____'+GetTranslator()+''
        return slot1
    except:
        pass

#Image Slot2
def getImageTeam2():
        imageteam = getUnknownImage()
        if fileExists('/boot/linuxrootfs2/etc/issue'):
            for line in open("/boot/linuxrootfs2/etc/issue"):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists('/boot/linuxrootfs2/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists('/boot/linuxrootfs2/etc/bhversion'):
                    for line in open('/boot/linuxrootfs2/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
               
def getS2():
    try:
        slot2 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs2') != -1 and not lines.find(''+namberout+'') :
                slot2 = '____'+GetTranslator()+''
        return slot2
    except:
        pass

#Image Slot3
def getImageTeam3():
        imageteam = getUnknownImage()
        if fileExists('/boot/linuxrootfs3/etc/issue'):
            for line in open("/boot/linuxrootfs3/etc/issue"):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists('/boot/linuxrootfs3/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists('/boot/linuxrootfs3/etc/bhversion'):
                    for line in open('/boot/linuxrootfs3/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
def getS3():
    try:
        slot3 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs3') != -1 and not lines.find(''+namberout+'') :
                slot3 = '____'+GetTranslator()+''
        return slot3
    except:
        pass
                                 
#Image Slot4
def getImageTeam4():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs4/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs4/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs4/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs4/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs4/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
def getS4():
    try:
        slot4 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs4') != -1 and not lines.find(''+namberout+'') :
                slot4 = '____'+GetTranslator()+''
        return slot4
    except:
        pass
                    
#Image Slot5
def getImageTeam5():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs5/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs5/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs5/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs5/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs5/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'     
        return imageteam
        
def getS5():
    try:
        slot5 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs5') != -1 and not lines.find(''+namberout+'') :
                slot5 = '____'+GetTranslator()+''
        return slot5
    except:
        pass
        
#Image Slot6
def getImageTeam6():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs6/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs6/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs6/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs6/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs6/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
def getS6():
    try:
        slot6 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs6') != -1 and not lines.find(''+namberout+'') :
                slot6 = '____'+GetTranslator()+''
        return slot6
    except:
        pass
            
#Image Slot7
def getImageTeam7():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs7/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs7/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs7/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs7/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs7/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
def getS7():
    try:
        slot7 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs7') != -1 and not lines.find(''+namberout+'') :
                slot7 = '____'+GetTranslator()+''
        return slot7
    except:
        pass
        
#Image Slot8
def getImageTeam8():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs8/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs8/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs8/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs8/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs8/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
def getS8():
    try:
        slot8 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs8') != -1 and not lines.find(''+namberout+'') :
                slot8 = '____'+GetTranslator()+''
        return slot8
    except:
        pass
        
#Image Slot9
def getImageTeam9():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs9/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs9/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs9/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs9/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs9/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
def getS9():
    try:
        slot9 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs9') != -1 and not lines.find(''+namberout+'') :
                slot9 = '____'+GetTranslator()+''
        return slot9
    except:
        pass
        
#Add next Slot:
def getImageTeam10():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs10/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs10/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs10/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs10/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs10/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
def getS10():
    try:
        slot10 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs10') != -1 :
                slot10 = '____'+GetTranslator()+''
        return slot10
    except:
        pass
        
        
#Add next Slot:
def getImageTeam11():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs11/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs11/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs11/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs11/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs11/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
               
def getS11():
    try:
        slot11 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs11') != -1 :
                slot11 = '____'+GetTranslator()+''
        return slot11
    except:
        pass
        
#Add next Slot:
def getImageTeam12():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs12/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs12/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs12/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs12/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs12/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
#Add next Slot:        
def getS12():
    try:
        slot12 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs12') != -1 :
                slot12 = '____'+GetTranslator()+''
        return slot12
    except:
        pass

#

#Add next Slot:
def getImageTeam13():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs13/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs13/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs13/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs13/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs13/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
#Add next Slot:        
def getS13():
    try:
        slot13 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs13') != -1 :
                slot13 = '____'+GetTranslator()+''
        return slot13
    except:
        pass
        
####>>>>

#Add next Slot:
def getImageTeam14():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs14/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs14/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs14/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs14/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs14/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
#Add next Slot:        
def getS14():
    try:
        slot14 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs14') != -1 :
                slot14 = '____'+GetTranslator()+''
        return slot14
    except:
        pass
#####>>>

#Add next Slot:
def getImageTeam15():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs15/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs15/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs15/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs15/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs15/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
#Add next Slot:        
def getS15():
    try:
        slot15 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs15') != -1 :
                slot15 = '____'+GetTranslator()+''
        return slot15
    except:
        pass
        
#####>>>

#Add next Slot:
def getImageTeam16():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs16/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs16/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs16/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs16/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs16/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
#Add next Slot:        
def getS16():
    try:
        slot16 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs16') != -1 :
                slot16 = '____'+GetTranslator()+''
        return slot16
    except:
        pass
        
#####>>>

#Add next Slot:
def getImageTeam17():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs17/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs17/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs17/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs17/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs17/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
#Add next Slot:        
def getS17():
    try:
        slot17 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs17') != -1 :
                slot17 = '____'+GetTranslator()+''
        return slot17
    except:
        pass
        
#####>>>

#Add next Slot:
def getImageTeam18():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs18/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs18/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs18/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs18/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs18/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
#Add next Slot:        
def getS18():
    try:
        slot18 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs18') != -1 :
                slot18 = '____'+GetTranslator()+''
        return slot18
    except:
        pass
        
#####>>>

#Add next Slot:
def getImageTeam19():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs19/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs19/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs19/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs19/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs19/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
#Add next Slot:        
def getS19():
    try:
        slot19 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs19') != -1 :
                slot19 = '____'+GetTranslator()+''
        return slot19
    except:
        pass
        
#####>>>

#Add next Slot:
def getImageTeam20():
        imageteam = getUnknownImage()
        if fileExists(''+getHddOrUsb()+'/linuxrootfs20/etc/issue'):
            for line in open(''+getHddOrUsb()+'/linuxrootfs20/etc/issue'):
                if "openbh" in line:
                    imageteam = 'OpenBH'
                elif "openspa" in line:
                    imageteam = 'OpenSPA'
                elif "egami" in line:
                    imageteam = 'EGAMI'
                elif "openvix" in line:
                    imageteam = 'OpenVix'
                elif "openatv" in line:
                    imageteam = 'openATV'
                elif "cobraliberosa" in line:
                    imageteam = 'Cobraliberosat'
                elif "openvision" in line:
                    imageteam = 'OpenVision'
                elif "opendroid" in line:
                    imageteam = 'OpenDroid'
                elif "openpli" in line:
                    imageteam = 'OpenPLi'
                elif "pure2" in line:
                    imageteam = 'PurE2'
                elif "Nonsolosat" in line:
                    imageteam = 'Nonsolosat'
                elif "rudream" in line:
                    imageteam = 'Rudream'
                elif "satdreamgr" in line:
                    imageteam = 'SatdreamGR'
                elif "opentr" in line:
                    imageteam = 'OpenTR'
                elif "openesi" in line:
                    imageteam = 'OpenESI'                    
                elif "openesi" in line:
                    imageteam = 'OpenESI'
                elif "openbox" in line:
                    imageteam = 'openBOX'
                elif "opendonki" in line:
                    imageteam = 'OpenDonki'
                elif "openplus" in line:
                    imageteam = 'OpenPlus'
                elif "openld" in line:
                    imageteam = 'OpenLD'
                elif "opennfr" in line:
                    imageteam = 'OpenNFR'
                elif "openten" in line:
                    imageteam = 'OpenTEN'
                elif "PKTeam" in line or "Hyperion" in line :
                    imageteam = 'PKTeamHyperion'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs20/etc/vtiversion.info'):
                    imageteam = 'VTiTeam'
                elif fileExists(''+getHddOrUsb()+'/linuxrootfs20/etc/bhversion'):
                    for line in open(''+getHddOrUsb()+'/linuxrootfs20/etc/bhversion'):
                        if "BlackHole" in line:
                            imageteam = 'BlackHole'
                elif "vuplus" in line:
                    imageteam = 'VuPlus'
        return imageteam
        
#Add next Slot:        
def getS20():
    try:
        slot20 = ""
        if fileExists('/boot/STARTUP'):
            with open('/boot/STARTUP', 'r') as f:
                lines = f.read()
                f.close()
            if lines.find('linuxrootfs20') != -1 :
                slot20 = '____'+GetTranslator()+''
        return slot20
    except:
        pass
        
#Add next Slot:        
#####>>>

def GetTranslator():
    imglang = ""
    usedlang = open('/etc/enigma2/settings', 'r')
    lang = 'config.osd.language=pl_PL'
    local = usedlang.read().find(lang)
    if local != -1:
        imglang = 'Aktualny'
    else:
        imglang = 'Current'
    return imglang
        
def getHddOrUsb():
    locatino = '/media/hdd'
    if fileExists('/media/hdd/STARTUP') and fileExists('/media/hdd/linuxrootfs'+namber+'/zImage'):
            locatino = '/media/hdd'
    elif fileExists('/media/usb/STARTUP') and fileExists('/media/usb/linuxrootfs'+namber+'/zImage'):
            locatino = '/media/usb'
    return locatino

def getMountDevices(): 
    if fileExists('/proc/mounts'):
        with open('/proc/mounts', 'r') as f:
            lines = f.read()
            f.close()
        if lines.find('/dev/sda1') != -1:
            if not fileExists('/media/hdd'):
                os.system('mkdir -p /media/hdd')
            os.system('mount /dev/sda1 /media/hdd')
        if lines.find('/dev/sdb1') != -1:
            if not fileExists('/media/usb'):
                os.system('mkdir -p /media/usb')
            os.system('mount /dev/sdb1 /media/usb')
            
def getMovNextIMG(): 
    if fileExists(''+getHddOrUsb()+'/linuxrootfs9/zImage'):
        if not fileExists(''+getHddOrUsb()+'/linuxrootfs10/zImage'):
            os.system('mv -f '+getHddOrUsb()+'/linuxrootfs9 '+getHddOrUsb()+'/linuxrootfs10; sleep 1; echo "kernel=/linuxrootfs10/zImage root=/dev/sda1 rootsubdir=linuxrootfs10" > /boot/STARTUP; sleep 1 ')
        elif not fileExists(''+getHddOrUsb()+'/linuxrootfs11/zImage'):
            os.system('mv -f '+getHddOrUsb()+'/linuxrootfs9 '+getHddOrUsb()+'/linuxrootfs11; sleep 1; echo "kernel=/linuxrootfs11/zImage root=/dev/sda1 rootsubdir=linuxrootfs11" > /boot/STARTUP; sleep 1 ')
        elif not fileExists(''+getHddOrUsb()+'/linuxrootfs12/zImage'):
            os.system('mv -f '+getHddOrUsb()+'/linuxrootfs9 '+getHddOrUsb()+'/linuxrootfs12; sleep 1; echo "kernel=/linuxrootfs12/zImage root=/dev/sda1 rootsubdir=linuxrootfs12" > /boot/STARTUP; sleep 1 ')
        elif not fileExists(''+getHddOrUsb()+'/linuxrootfs13/zImage'):
            os.system('mv -f '+getHddOrUsb()+'/linuxrootfs9 '+getHddOrUsb()+'/linuxrootfs13; sleep 1; echo "kernel=/linuxrootfs13/zImage root=/dev/sda1 rootsubdir=linuxrootfs13" > /boot/STARTUP; sleep 1 ')
        elif not fileExists(''+getHddOrUsb()+'/linuxrootfs14/zImage'):
            os.system('mv -f '+getHddOrUsb()+'/linuxrootfs9 '+getHddOrUsb()+'/linuxrootfs14; sleep 1; echo "kernel=/linuxrootfs14/zImage root=/dev/sda1 rootsubdir=linuxrootfs14" > /boot/STARTUP; sleep 1 ')
        elif not fileExists(''+getHddOrUsb()+'/linuxrootfs15/zImage'):
            os.system('mv -f '+getHddOrUsb()+'/linuxrootfs9 '+getHddOrUsb()+'/linuxrootfs15; sleep 1; echo "kernel=/linuxrootfs15/zImage root=/dev/sda1 rootsubdir=linuxrootfs15" > /boot/STARTUP; sleep 1 ')
        elif not fileExists(''+getHddOrUsb()+'/linuxrootfs16/zImage'):
            os.system('mv -f '+getHddOrUsb()+'/linuxrootfs9 '+getHddOrUsb()+'/linuxrootfs16; sleep 1; echo "kernel=/linuxrootfs16/zImage root=/dev/sda1 rootsubdir=linuxrootfs16" > /boot/STARTUP; sleep 1 ')
        elif not fileExists(''+getHddOrUsb()+'/linuxrootfs17/zImage'):
            os.system('mv -f '+getHddOrUsb()+'/linuxrootfs9 '+getHddOrUsb()+'/linuxrootfs17; sleep 1; echo "kernel=/linuxrootfs17/zImage root=/dev/sda1 rootsubdir=linuxrootfs17" > /boot/STARTUP; sleep 1 ')
        elif not fileExists(''+getHddOrUsb()+'/linuxrootfs18/zImage'):
            os.system('mv -f '+getHddOrUsb()+'/linuxrootfs9 '+getHddOrUsb()+'/linuxrootfs18; sleep 1; echo "kernel=/linuxrootfs18/zImage root=/dev/sda1 rootsubdir=linuxrootfs18" > /boot/STARTUP; sleep 1 ')
        elif not fileExists(''+getHddOrUsb()+'/linuxrootfs19/zImage'):
            os.system('mv -f '+getHddOrUsb()+'/linuxrootfs9 '+getHddOrUsb()+'/linuxrootfs19; sleep 1; echo "kernel=/linuxrootfs19/zImage root=/dev/sda1 rootsubdir=linuxrootfs19" > /boot/STARTUP; sleep 1 ')
        elif not fileExists(''+getHddOrUsb()+'/linuxrootfs20/zImage'):
            os.system('mv -f '+getHddOrUsb()+'/linuxrootfs9 '+getHddOrUsb()+'/linuxrootfs20; sleep 1; echo "kernel=/linuxrootfs20/zImage root=/dev/sda1 rootsubdir=linuxrootfs20" > /boot/STARTUP; sleep 1 ')
        elif not fileExists(''+getHddOrUsb()+'/linuxrootfs21/zImage'):
            os.system('mv -f '+getHddOrUsb()+'/linuxrootfs9 '+getHddOrUsb()+'/linuxrootfs21; sleep 1; echo "kernel=/linuxrootfs21/zImage root=/dev/sda1 rootsubdir=linuxrootfs21" > /boot/STARTUP; sleep 1 ')
        elif not fileExists(''+getHddOrUsb()+'/linuxrootfs22/zImage'):
            os.system('mv -f '+getHddOrUsb()+'/linuxrootfs9 '+getHddOrUsb()+'/linuxrootfs22; sleep 1; echo "kernel=/linuxrootfs22/zImage root=/dev/sda1 rootsubdir=linuxrootfs22" > /boot/STARTUP; sleep 1 ')


#END script gutosie
